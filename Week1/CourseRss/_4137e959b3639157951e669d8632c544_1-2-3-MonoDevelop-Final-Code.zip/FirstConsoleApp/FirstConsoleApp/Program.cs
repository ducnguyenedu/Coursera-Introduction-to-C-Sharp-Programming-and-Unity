﻿using System;

namespace FirstConsoleApp
{
    /// <summary>
    /// First Console App lecture code
    /// </summary>
    class MainClass
    {
        /// <summary>
        /// Prints a message
        /// </summary>
        /// <param name="args">command-line arguments</param>
        public static void Main(string[] args)
        {
            // print supportive message
            Console.WriteLine("Hi, n00b!");
            
            Console.WriteLine();
        }
    }
}
